export default function Home() {
  return (
    <main style={{
      minHeight: "100vh",
      background: "linear-gradient(to bottom, #020617, #0f172a)",
      color: "white",
      padding: "40px",
      fontFamily: "Arial"
    }}>
      <div style={{ maxWidth: "900px", margin: "auto" }}>

        <h1 style={{ fontSize: "48px", fontWeight: "bold" }}>
          Come All Bank
        </h1>

        <p style={{ color: "#cbd5e1", fontSize: "18px" }}>
          A financial system built for everyone — from a penny to a billion
        </p>

        <p style={{ marginTop: "10px", fontStyle: "italic", color: "#94a3b8" }}>
          “The Fusion of Revolution or Evolution”
        </p>

        <hr style={{ margin: "30px 0", opacity: 0.2 }} />

        <h2>Our Vision</h2>
        <p style={{ color: "#cbd5e1" }}>
          Come All Bank is an inclusive financial ecosystem designed for secure digital finance and future growth.
        </p>

        <h2 style={{ marginTop: "30px" }}>Core Features</h2>
        <ul style={{ color: "#cbd5e1", lineHeight: "1.8" }}>
          <li>Universal Access</li>
          <li>AI Security Concept Layer</li>
          <li>Cross-network readiness</li>
          <li>Modern fintech design</li>
        </ul>

        <div style={{ marginTop: "40px" }}>
          <a href="https://buy.stripe.com/test"
            style={{
              background: "white",
              color: "black",
              padding: "12px 20px",
              borderRadius: "8px",
              fontWeight: "bold",
              textDecoration: "none"
            }}>
            Join / Pay with Stripe
          </a>
        </div>

      </div>
    </main>
  );
}
